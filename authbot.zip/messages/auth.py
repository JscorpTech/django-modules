send_phone = "Telefon nomerni yuborish 📲"
you_otp = "Sizning tasdiqlash ko'dingiz: {}"
loading = "Iltimos kuting..."
