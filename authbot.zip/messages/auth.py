send_phone = "Telefon nomerni yuborish 📲"
you_otp = (
    "Sizning tasdiqlash ko'dingiz: ```{}```\nAmal qilish muddati: *10 daqiqa*"
)
loading = "Iltimos kuting..."
