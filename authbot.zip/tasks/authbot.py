from celery import shared_task
from ..models import Code
from datetime import timedelta, datetime


@shared_task
def clear_old_codes():
    return Code.objects.filter(created_at__gte=datetime.now() - timedelta(minutes=10)).delete()
