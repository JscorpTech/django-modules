from core.http.models import AbstractBaseModel
from django.db import models


class BotUser(AbstractBaseModel):
    user_id = models.BigIntegerField()
    first_name = models.CharField(max_length=1000, null=True, blank=True)
    last_name = models.CharField(max_length=1000, null=True, blank=True)
    phone = models.CharField(max_length=255)
