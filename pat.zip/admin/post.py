from django.db import models as db_model
from django_select2 import forms as django_select2
from modeltranslation import admin as modeltranslation
from unfold.admin import ModelAdmin
from django.contrib import admin

from .. import models, forms


class PostAdmin(
    modeltranslation.TabbedTranslationAdmin,
    ModelAdmin,
):  # noqa
    fields: tuple = ("title", "desc", "image", "tags")
    search_fields: list = ["title", "desc"]
    list_filter = ["title"]
    required_languages: tuple = ("uz",)
    form = forms.PostAdminForm
    formfield_overrides = {
        db_model.ManyToManyField: {"widget": django_select2.Select2MultipleWidget}
    }


class TagsAdmin(ModelAdmin):
    fields: tuple = ("name",)
    search_fields: list = ["name"]


class CommentAdmin(ModelAdmin):
    list_display = ["text"]
    search_fields = ["text"]


admin.site.register(models.Post, PostAdmin)
admin.site.register(models.Comment, CommentAdmin)
admin.site.register(models.Tags, TagsAdmin)
