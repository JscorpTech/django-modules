from unfold.admin import ModelAdmin
from django.contrib import admin
from ..models import FrontendTranslation


class FrontendTranslationAdmin(ModelAdmin):  # noqa
    fields: tuple = ("key", "value")
    required_languages: tuple = ("uz",)
    list_display = ["key", "value"]


admin.site.register(FrontendTranslation, FrontendTranslationAdmin)